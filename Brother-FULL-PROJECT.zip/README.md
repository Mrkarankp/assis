# My Assistant (Android, offline-first)
1. Install Android Studio, then File > Open this folder and let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run.
3. Offline speech: Settings > System > Languages > Speech/Voice input, download your language for offline use.
4. Commands: what time is it, what's the date, set a timer for 5 minutes, set an alarm for 7:30 am,
   call 9876543210, open WhatsApp, flashlight on/off, battery level, note buy milk, read my notes, search <text>.
5. Optional: Settings > Default apps > Digital assistant app > choose "My Assistant" (long-press power/home opens it).
